const dummyOrders = [
  {
    _id: "o1",
    userId: "u1",
    products: [{ productId: "p1", quantity: 2 }],
    total: 1198,
    status: "Processing",
  },
];
export default dummyOrders;