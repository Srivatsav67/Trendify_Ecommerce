const dummyUsers = [
  {
    _id: "u1",
    name: "Srivatsav",
    email: "srivatsav@example.com",
    role: "admin",
  },
  {
    _id: "u2",
    name: "Ravi",
    email: "ravi@example.com",
    role: "user",
  },
];
export default dummyUsers;