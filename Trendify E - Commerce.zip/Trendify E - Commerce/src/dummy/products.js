const dummyProducts = [
  {
    _id: "p1",
    name: "Oversized T-Shirt",
    price: 599,
    brand: "Trendify",
    category: "Men",
    size: ["M", "L", "XL"],
    image: "https://via.placeholder.com/300x400",
    rating: 4.5,
    stock: 50,
  },
  {
    _id: "p2",
    name: "Graphic Hoodie",
    price: 999,
    brand: "Trendify",
    category: "Women",
    size: ["S", "M", "L"],
    image: "https://via.placeholder.com/300x400",
    rating: 4.8,
    stock: 30,
  },
];
export default dummyProducts;