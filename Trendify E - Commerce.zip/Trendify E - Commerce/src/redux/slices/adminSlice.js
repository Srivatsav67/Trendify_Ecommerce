import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  products: [],
  orders: [],
  users: [],
  dashboardStats: {},
};

const adminSlice = createSlice({
  name: 'admin',
  initialState,
  reducers: {
    setProducts: (state, action) => {
      state.products = action.payload;
    },
    setOrders: (state, action) => {
      state.orders = action.payload;
    },
    setUsers: (state, action) => {
      state.users = action.payload;
    },
    setDashboardStats: (state, action) => {
      state.dashboardStats = action.payload;
    },
  },
});

export const { setProducts, setOrders, setUsers, setDashboardStats } = adminSlice.actions;
export default adminSlice.reducer;